# Lumi Subtitles

A small Android app that translates subtitle files into your language with Google's offline translator (ML Kit).

- Opens `.srt`, `.vtt`, `.ass` and `.ssa` files (UTF-8, UTF-16 or old Windows encoding).
- Auto-detects the subtitle's language, or you pick it.
- Indian languages first: Hindi, Tamil, Telugu, Bengali, Marathi, Kannada, Gujarati, Urdu, plus about 50 more.
- Progress bar with line count and percentage, and a Cancel button.
- Keeps line breaks, italics and dialogue dashes. Skips lines with only music notes or symbols. Repeated lines are translated once.
- Saves as `movie.hi.srt` (UTF-8), so players like VideoQ, VLC and MX Player load it automatically next to `movie.mp4`.
- You can also open or share a subtitle file to Lumi from a file manager.
- No account, no API key, no server. Each language pack (about 30 MB) downloads once, then translation works offline.

## Build

1. Open this folder in **Android Studio** (any recent version) and let it sync.
   If it offers to update the Android Gradle Plugin or Kotlin, accept.
2. Plug in your phone (USB debugging on) and press **Run**, or
   **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
3. For the smallest file, build **release**: *Build › Select Build Variant › release*, then build the APK.
   Release is shrunk and minified. It's signed with the debug key so you can install it directly.
   Use your own signing key before publishing on the Play Store.

Unit tests for the subtitle parser: `./gradlew test`. Android Studio creates the `gradlew` wrapper on first sync,
or run `gradle wrapper` once.

## Files

- `MainActivity.kt`: the single screen. Picking and saving files, language pickers, translation and progress.
- `SubtitleParser.kt`: reads SRT, VTT and ASS files, writes SRT, detects text encoding.
- `LineTools.kt`: keeps tags and dashes out of the text sent for translation.
