package com.lumi.subtitles

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** One subtitle entry. Each line is translated separately so line breaks survive. */
data class Cue(val startMs: Long, val endMs: Long, val lines: List<String>)

object SubtitleParser {

    private val TIME = Regex("""(?:(\d+):)?(\d{1,2}):(\d{1,2})[,.](\d{1,3})""")
    private val BLANK_LINE = Regex("""\n[ \t]*\n""")
    private val ASS_OVERRIDE = Regex("""\{[^}]*\}""")

    /** Picks the parser from the file name, falling back to content sniffing. */
    fun parse(text: String, fileName: String): List<Cue> {
        val clean = text.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
        val lower = fileName.lowercase()
        val isAss = lower.endsWith(".ass") || lower.endsWith(".ssa") ||
            clean.contains("[Events]", ignoreCase = true)
        return if (isAss) parseAss(clean) else parseSrtOrVtt(clean)
    }

    /** SubRip (.srt) and WebVTT (.vtt). */
    fun parseSrtOrVtt(text: String): List<Cue> {
        val cues = ArrayList<Cue>()
        for (block in text.split(BLANK_LINE)) {
            val lines = block.split('\n').map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue
            val first = lines[0].trim()
            if (first.startsWith("WEBVTT") || first.startsWith("NOTE") || first.startsWith("STYLE")) continue

            val timeIdx = lines.indexOfFirst { it.contains("-->") }
            if (timeIdx == -1) continue
            val parts = lines[timeIdx].split("-->")
            if (parts.size < 2) continue
            val start = parseTime(parts[0]) ?: continue
            val end = parseTime(parts[1].trim().split(Regex("""\s+""")).first()) ?: continue
            if (end <= start) continue

            val body = lines.drop(timeIdx + 1)
            if (body.isEmpty()) continue
            cues += Cue(start, end, body)
        }
        return cues.sortedBy { it.startMs }
    }

    /** Advanced SubStation (.ass / .ssa): reads the Dialogue lines of [Events]. */
    fun parseAss(text: String): List<Cue> {
        val cues = ArrayList<Cue>()
        var fields = listOf("layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text")
        var inEvents = false
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.startsWith("[")) { inEvents = line.equals("[Events]", ignoreCase = true); continue }
            if (!inEvents) continue
            if (line.startsWith("Format:", ignoreCase = true)) {
                fields = line.substringAfter(':').split(',').map { it.trim().lowercase() }
                continue
            }
            if (!line.startsWith("Dialogue:", ignoreCase = true)) continue
            val iStart = fields.indexOf("start")
            val iEnd = fields.indexOf("end")
            val iText = fields.indexOf("text")
            if (iStart < 0 || iEnd < 0 || iText < 0) continue
            val values = line.substringAfter(':').split(',', limit = fields.size)
            if (values.size < fields.size) continue
            val start = parseTime(values[iStart].trim() + "0") ?: continue
            val end = parseTime(values[iEnd].trim() + "0") ?: continue
            val body = values[iText]
                .replace(ASS_OVERRIDE, "")
                .replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
                .split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            if (body.isEmpty() || end <= start) continue
            cues += Cue(start, end, body)
        }
        return cues.sortedBy { it.startMs }
    }

    /** "01:02:03,456", "02:03.456" or ASS "1:02:03.45" (padded) to milliseconds. */
    fun parseTime(raw: String): Long? {
        val m = TIME.find(raw.trim()) ?: return null
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        val min = m.groupValues[2].toLong()
        val s = m.groupValues[3].toLong()
        val ms = m.groupValues[4].padEnd(3, '0').take(3).toLong()
        return ((h * 60 + min) * 60 + s) * 1000 + ms
    }

    fun formatSrtTime(ms: Long): String {
        val h = ms / 3_600_000
        val m = ms % 3_600_000 / 60_000
        val s = ms % 60_000 / 1000
        val milli = ms % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, milli)
    }

    fun toSrt(cues: List<Cue>): String = buildString {
        cues.forEachIndexed { i, c ->
            append(i + 1).append('\n')
            append(formatSrtTime(c.startMs)).append(" --> ").append(formatSrtTime(c.endMs)).append('\n')
            c.lines.forEach { append(it).append('\n') }
            append('\n')
        }
    }

    /** Handles UTF-8 (with or without BOM), UTF-16, and old Windows-1252 files. */
    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte())
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            String(bytes, Charset.forName("windows-1252"))
        }
    }
}
