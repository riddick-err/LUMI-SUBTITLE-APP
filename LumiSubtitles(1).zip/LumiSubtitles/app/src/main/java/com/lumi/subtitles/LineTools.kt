package com.lumi.subtitles

/** Splits a subtitle line into the parts we keep as-is and the part we translate. */
object LineTools {

    private val TAG = Regex("""<[^>]+>|\{\\[^}]*\}""")
    private val DASH = Regex("""^(-\s*)""")
    private val LETTER = Regex("""\p{L}""")

    data class Parts(val prefix: String, val body: String, val italic: Boolean)

    fun stripTags(line: String): String = line.replace(TAG, "").trim()

    /** Null when the line has nothing to translate (only symbols, numbers or music notes). */
    fun split(line: String): Parts? {
        val trimmed = line.trim()
        val italic = trimmed.startsWith("<i>", ignoreCase = true) && trimmed.endsWith("</i>", ignoreCase = true)
        val plain = stripTags(trimmed)
        if (!LETTER.containsMatchIn(plain)) return null
        val prefix = DASH.find(plain)?.value ?: ""
        val body = plain.removePrefix(prefix).trim()
        if (body.isEmpty()) return null
        return Parts(prefix, body, italic)
    }

    fun join(parts: Parts, translatedBody: String): String {
        val text = parts.prefix + translatedBody.trim()
        return if (parts.italic) "<i>$text</i>" else text
    }
}
