package com.lumi.subtitles

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private val scope = MainScope()
    private var job: Job? = null

    private var cues: List<Cue> = emptyList()
    private var translated: List<Cue>? = null
    private var fileBaseName = "subtitle"
    private var lastTarget = TranslateLanguage.HINDI

    private lateinit var pickButton: Button
    private lateinit var fileInfo: TextView
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var wifiOnly: CheckBox
    private lateinit var translateButton: Button
    private lateinit var progressGroup: View
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var percentText: TextView
    private lateinit var cancelButton: Button
    private lateinit var resultGroup: View
    private lateinit var previewText: TextView
    private lateinit var saveButton: Button

    /** Indian languages first, then everything else ML Kit can translate. */
    private val languages: List<String> by lazy {
        val first = listOf(
            TranslateLanguage.HINDI, TranslateLanguage.TAMIL, TranslateLanguage.TELUGU,
            TranslateLanguage.BENGALI, TranslateLanguage.MARATHI, TranslateLanguage.KANNADA,
            TranslateLanguage.GUJARATI, TranslateLanguage.URDU, TranslateLanguage.ENGLISH
        )
        val rest = TranslateLanguage.getAllLanguages()
            .filter { it !in first }
            .sortedBy { Locale.forLanguageTag(it).getDisplayLanguage(Locale.ENGLISH) }
        first + rest
    }
    private val sourceOptions: List<String?> by lazy { listOf<String?>(null) + languages }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pickButton = findViewById(R.id.pickButton)
        fileInfo = findViewById(R.id.fileInfo)
        sourceSpinner = findViewById(R.id.sourceSpinner)
        targetSpinner = findViewById(R.id.targetSpinner)
        wifiOnly = findViewById(R.id.wifiOnly)
        translateButton = findViewById(R.id.translateButton)
        progressGroup = findViewById(R.id.progressGroup)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        percentText = findViewById(R.id.percentText)
        cancelButton = findViewById(R.id.cancelButton)
        resultGroup = findViewById(R.id.resultGroup)
        previewText = findViewById(R.id.previewText)
        saveButton = findViewById(R.id.saveButton)

        sourceSpinner.adapter = adapter(sourceOptions.map { it?.let(::label) ?: getString(R.string.auto_detect) })
        targetSpinner.adapter = adapter(languages.map(::label))

        val prefs = getSharedPreferences("lumi", Context.MODE_PRIVATE)
        val savedTarget = prefs.getString("target", TranslateLanguage.HINDI)
        targetSpinner.setSelection(languages.indexOf(savedTarget).coerceAtLeast(0))
        wifiOnly.isChecked = prefs.getBoolean("wifiOnly", true)

        pickButton.setOnClickListener { pickFile() }
        translateButton.setOnClickListener { startTranslation() }
        cancelButton.setOnClickListener { job?.cancel() }
        saveButton.setOnClickListener { askWhereToSave() }

        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- files

    private fun handleIncoming(intent: Intent?) {
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND ->
                if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) loadFile(uri)
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_OPEN)
    }

    private fun askWhereToSave() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/x-subrip")
            // "movie.hi.srt" lets most players pick it up automatically next to "movie.mp4".
            .putExtra(Intent.EXTRA_TITLE, "$fileBaseName.$lastTarget.srt")
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SAVE)
    }

    @Deprecated("Framework Activity result API keeps the app free of extra libraries.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_OPEN -> loadFile(uri)
            REQ_SAVE -> save(uri)
        }
    }

    private fun loadFile(uri: Uri) {
        job?.cancel()
        scope.launch {
            try {
                val name = displayName(uri)
                val parsed = withContext(Dispatchers.IO) {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: error("Can't open this file")
                    SubtitleParser.parse(SubtitleParser.decode(bytes), name)
                }
                if (parsed.isEmpty()) {
                    toast("No subtitle lines found in $name")
                    return@launch
                }
                cues = parsed
                translated = null
                fileBaseName = name.substringBeforeLast('.')
                fileInfo.text = "$name\n${fmt(parsed.size)} lines"
                fileInfo.setTextColor(getColor(R.color.text))
                translateButton.isEnabled = true
                resultGroup.visibility = View.GONE
                progressGroup.visibility = View.GONE
            } catch (e: Exception) {
                toast("Couldn't read the file: ${e.message}")
            }
        }
    }

    private fun save(uri: Uri) {
        val result = translated ?: return
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri, "wt")?.use { out ->
                        // UTF-8 with BOM: TVs and older players read Indian scripts correctly.
                        out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                        out.write(SubtitleParser.toSrt(result).toByteArray(Charsets.UTF_8))
                    } ?: error("Can't write here")
                }
                toast("Saved")
            } catch (e: Exception) {
                toast("Couldn't save: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------- translation

    private fun startTranslation() {
        if (cues.isEmpty() || job?.isActive == true) return
        val target = languages[targetSpinner.selectedItemPosition]
        val chosenSource = sourceOptions[sourceSpinner.selectedItemPosition]
        lastTarget = target
        getSharedPreferences("lumi", Context.MODE_PRIVATE).edit()
            .putString("target", target)
            .putBoolean("wifiOnly", wifiOnly.isChecked)
            .apply()

        job = scope.launch {
            setBusy(true)
            var translator: Translator? = null
            try {
                // 1. Source language
                val source = chosenSource ?: run {
                    showStage("Detecting language…")
                    detectLanguage() ?: return@launch fail(
                        "Couldn't detect the language. Choose it under \"From\"."
                    )
                }
                if (source == target) return@launch fail("The subtitle is already in ${label(target)}.")

                // 2. Language packs
                val needed = listOf(source, target).filter { it != TranslateLanguage.ENGLISH }
                val missing = needed.filterNot { isDownloaded(it) }
                if (missing.isNotEmpty() && wifiOnly.isChecked && isOnMobileData()) {
                    return@launch fail(
                        "The ${missing.joinToString(" and ") { english(it) }} language pack needs a " +
                            "one-time download (about 30 MB). Connect to Wi-Fi, or untick \"Wi-Fi only\"."
                    )
                }
                val client = Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
                )
                translator = client
                if (missing.isNotEmpty()) {
                    showStage("Downloading ${missing.joinToString(" + ") { english(it) }} language pack…")
                }
                client.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()

                // 3. Translate
                val result = translateAll(client, target)
                translated = result
                showResult(result, target)
            } catch (e: CancellationException) {
                statusText.text = "Cancelled"
                percentText.text = ""
            } catch (e: Exception) {
                fail("Something went wrong: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                translator?.close()
                setBusy(false)
            }
        }
    }

    private suspend fun translateAll(translator: Translator, target: String): List<Cue> {
        val total = cues.size
        val out = arrayOfNulls<Cue>(total)
        val cache = ConcurrentHashMap<String, String>() // repeated lines are translated once
        val gate = Semaphore(4)
        var done = 0

        updateProgress(0, total, target)
        coroutineScope {
            cues.forEachIndexed { index, cue ->
                launch {
                    gate.withPermit {
                        val lines = cue.lines.map { line ->
                            val parts = LineTools.split(line) ?: return@map line
                            val text = cache[parts.body]
                                ?: translator.translate(parts.body).await().also { cache[parts.body] = it }
                            LineTools.join(parts, text)
                        }
                        out[index] = cue.copy(lines = lines)
                        done++ // runs on the main thread, so no race
                        if (done % 3 == 0 || done == total) updateProgress(done, total, target)
                    }
                }
            }
        }
        return out.map { requireNotNull(it) }
    }

    private suspend fun detectLanguage(): String? {
        val sample = cues.asSequence().take(80)
            .flatMap { it.lines.asSequence() }
            .map(LineTools::stripTags)
            .joinToString(" ")
            .take(2000)
        val client = LanguageIdentification.getClient()
        return try {
            val tag = client.identifyLanguage(sample).await()
            if (tag == "und") null else TranslateLanguage.fromLanguageTag(tag)
        } finally {
            client.close()
        }
    }

    private suspend fun isDownloaded(code: String): Boolean = try {
        RemoteModelManager.getInstance()
            .isModelDownloaded(TranslateRemoteModel.Builder(code).build()).await()
    } catch (e: Exception) {
        false
    }

    private fun isOnMobileData(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.isActiveNetworkMetered
    }

    // ------------------------------------------------------------------- UI

    private fun setBusy(busy: Boolean) {
        translateButton.isEnabled = !busy && cues.isNotEmpty()
        pickButton.isEnabled = !busy
        sourceSpinner.isEnabled = !busy
        targetSpinner.isEnabled = !busy
        cancelButton.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            progressGroup.visibility = View.VISIBLE
            resultGroup.visibility = View.GONE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            progressBar.isIndeterminate = false
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun showStage(text: String) {
        statusText.text = text
        percentText.text = ""
        progressBar.isIndeterminate = true
    }

    private fun updateProgress(done: Int, total: Int, target: String) {
        progressBar.isIndeterminate = false
        progressBar.progress = if (total == 0) 0 else (done * 1000L / total).toInt()
        statusText.text = "Translating to ${native(target)}…"
        val pct = if (total == 0) 0 else done * 100 / total
        percentText.text = "${fmt(done)} / ${fmt(total)} lines · $pct%"
    }

    private fun showResult(result: List<Cue>, target: String) {
        progressBar.isIndeterminate = false
        progressBar.progress = 1000
        statusText.text = "Done! ${fmt(result.size)} lines translated to ${native(target)}"
        percentText.text = "100%"
        previewText.text = buildString {
            result.zip(cues).take(6).forEachIndexed { i, (new, old) ->
                if (i > 0) append("\n\n")
                append(SubtitleParser.formatSrtTime(new.startMs).dropLast(4)).append('\n')
                append(old.lines.joinToString(" ") { LineTools.stripTags(it) }).append('\n')
                append("→ ").append(new.lines.joinToString(" ") { LineTools.stripTags(it) })
            }
        }
        resultGroup.visibility = View.VISIBLE
    }

    private fun fail(message: String) {
        progressBar.isIndeterminate = false
        progressBar.progress = 0
        statusText.text = message
        percentText.text = ""
    }

    private fun adapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun english(code: String) = Locale.forLanguageTag(code).getDisplayLanguage(Locale.ENGLISH)

    private fun native(code: String): String {
        val loc = Locale.forLanguageTag(code)
        return loc.getDisplayLanguage(loc).replaceFirstChar { it.titlecase(loc) }
    }

    /** "हिन्दी · Hindi" */
    private fun label(code: String): String {
        val n = native(code)
        val e = english(code)
        return if (n.equals(e, ignoreCase = true)) e else "$n · $e"
    }

    private fun fmt(n: Int) = NumberFormat.getIntegerInstance().format(n)

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { return it }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "subtitle.srt"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private companion object {
        const val REQ_OPEN = 1
        const val REQ_SAVE = 2
    }
}
