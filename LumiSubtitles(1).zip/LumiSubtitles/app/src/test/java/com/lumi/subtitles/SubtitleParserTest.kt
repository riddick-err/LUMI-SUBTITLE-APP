package com.lumi.subtitles

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SubtitleParserTest {

    @Test fun parsesSrtWithMultiLineCues() {
        val srt = "﻿1\r\n00:00:01,500 --> 00:00:03,000\r\nHello there\r\n<i>General Kenobi</i>\r\n\r\n2\r\n00:01:02,000 --> 00:01:04,250\r\nBye\r\n"
        val cues = SubtitleParser.parse(srt, "movie.srt")
        assertEquals(2, cues.size)
        assertEquals(1500L, cues[0].startMs)
        assertEquals(listOf("Hello there", "<i>General Kenobi</i>"), cues[0].lines)
        assertEquals(64250L, cues[1].endMs)
    }

    @Test fun parsesVttWithShortTimesAndSettings() {
        val vtt = "WEBVTT\n\nNOTE comment\n\n00:05.000 --> 00:07.500 align:start\nHi\n"
        val cues = SubtitleParser.parse(vtt, "a.vtt")
        assertEquals(1, cues.size)
        assertEquals(5000L, cues[0].startMs)
        assertEquals(7500L, cues[0].endMs)
    }

    @Test fun parsesAssDialogue() {
        val ass = "[Script Info]\nTitle: x\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n" +
            "Dialogue: 0,0:00:01.20,0:00:02.50,Default,,0,0,0,,{\\an8}Line one\\NLine, two\n"
        val cues = SubtitleParser.parse(ass, "a.ass")
        assertEquals(1, cues.size)
        assertEquals(1200L, cues[0].startMs)
        assertEquals(listOf("Line one", "Line, two"), cues[0].lines)
    }

    @Test fun srtRoundTrip() {
        val cues = listOf(Cue(3_723_004, 3_725_000, listOf("नमस्ते", "दुनिया")))
        val again = SubtitleParser.parse(SubtitleParser.toSrt(cues), "x.srt")
        assertEquals(cues, again)
    }

    @Test fun lineToolsKeepsDashAndItalicsAndSkipsSymbols() {
        val p = LineTools.split("<i>- Where are you?</i>")!!
        assertEquals("Where are you?", p.body)
        assertEquals("<i>- Kahan ho?</i>", LineTools.join(p, "Kahan ho?"))
        assertNull(LineTools.split("♪ ♪"))
        assertNull(LineTools.split("123"))
    }

    @Test fun decodesWindows1252Fallback() {
        val bytes = byteArrayOf(0x63, 0x61, 0x66, 0xE9.toByte()) // "café" in Windows-1252
        assertEquals("café", SubtitleParser.decode(bytes))
    }
}
